<?php

$keyId = 'keyID';
$keySecret = 'keySecret';
$displayCurrency = 'INR';

error_reporting(E_ALL);
ini_set('display_errors', 1);


//DATABASE CONNECTION DETAILS//
$host = "localhost";
$username = "root";
$password = "root";
$dbname = "dbname";